﻿using namespace std;
#include "source/Simulator/CitySimulator.h"

int main() {
    CitySimulator simulator;
    simulator.run();
    return 0;
}
